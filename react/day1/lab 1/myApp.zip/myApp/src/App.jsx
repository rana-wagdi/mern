import React from 'react';
import Products from './Components/Products';
import Header from './Components/Header'
import Footer from './Components/Footer'

let App = () => {

    

    return (
        <div>
        
        <Header />
            <Products  />
            <Footer />
            
        
        </div>

    )
}

export default App ;


